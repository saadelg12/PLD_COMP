int main() {
    int a = 8;
    int b = 5;
    int c = 2;
    
    int result = a | b + c;
    
    return result;
}
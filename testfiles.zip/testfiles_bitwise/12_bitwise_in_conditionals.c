int main() {
    int a = 5;
    int b = 3;
    int result;
    
    if(a & b) {
        result = 42;
    } else {
        result = 0;
    }
    
    return result;
}

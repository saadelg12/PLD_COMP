int main() {
    int a = 42;
    int b = 0;
    
    int result = a | b;
    
    return result;
}
int main() {
    int a = 13;
    int b = 7;
    int c = 10;
    int d = 4;
    
    int result = (a + b) & (c - d);
    
    return result;
}
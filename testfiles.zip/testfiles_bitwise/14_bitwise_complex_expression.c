int main() {
    int a = 12;
    int b = 5;
    int c = 7;
    int d = 9;
    
    int result = (a & b) | (c ^ d);
    
    return result;
}
int main() {
    return 6 | 3;
}

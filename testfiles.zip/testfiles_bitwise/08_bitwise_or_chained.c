int main() {
	int a = 1;
	int b = 2;
	int c = 4;
	
	int result = a | b | c;
	
	return result;
}

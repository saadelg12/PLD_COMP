int main() {
    int a = 15;
    int b = 0;
    
    int result = a & b;
    
    return result;
}
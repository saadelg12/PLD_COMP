int main() {
    int a = -12;
    int b = 5;
    
    int result = a | b;
    
    return result;
}
int main() {
    int a = 15;
    int b = 6;
    int result = 0;
    
    result = a & b;
    result = result | 9;
    
    return result;
}
int main() {
    int a = 15;  
    int b = 10;  
    int result = a ^ b; 
    
    return result;
}
int main() {
	int a = 12;
	int b = 10;
	int c = 3;
	
	int result = (a & b) | c;
	
	return result;
}

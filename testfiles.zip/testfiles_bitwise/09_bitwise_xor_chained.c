int main() {
	int a = 3;
	int b = 5;
	int c = 6;

	int result = a ^ b ^ c;
	
	return result;
}

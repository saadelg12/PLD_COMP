int main() {
    int a = -8;
    int b = 3;
    
    int result = a ^ b;
    
    return result;
}
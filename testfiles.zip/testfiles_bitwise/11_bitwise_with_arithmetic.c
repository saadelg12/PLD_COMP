int main() {
	int a = 9;
	int b = 6;
	
	int result = (a & b) + (a | b);
	
	return result;
}

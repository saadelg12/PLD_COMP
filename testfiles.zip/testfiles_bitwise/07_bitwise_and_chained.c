int main() {
    int a = 15;  
    int b = 10;  
    int c = 6;   
    
    
    int result = a & b & c;
    
    return result;
}
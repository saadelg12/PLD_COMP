int main() {
    int a = 10;
    int b = 7;
    int c = 3;
    
    int result = a ^ b * c;
    
    return result;
}
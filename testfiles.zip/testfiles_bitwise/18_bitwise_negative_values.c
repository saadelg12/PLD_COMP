int main() {
    int a = -15;
    int b = 7;
    
    int result = a & b;
    
    return result;
}
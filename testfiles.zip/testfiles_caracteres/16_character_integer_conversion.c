int main() {
    int a = 'A';
    return a + 1;
}
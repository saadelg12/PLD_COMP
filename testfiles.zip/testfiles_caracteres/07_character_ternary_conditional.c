int main() {
    return ('A' > 'B') ? 'A' : 'B';
}
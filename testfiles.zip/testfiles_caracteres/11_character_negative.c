int main() {
    return -'A';
}
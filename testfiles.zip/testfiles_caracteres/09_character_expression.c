int main() {
    return ('a' - 'A') + 1;
}

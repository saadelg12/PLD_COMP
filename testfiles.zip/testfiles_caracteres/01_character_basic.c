int main() {
    return 'Z';
}

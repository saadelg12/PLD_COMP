int main() {
    return 'A' + 1;
}

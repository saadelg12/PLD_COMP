int main() {
    return ('A' + 1) & ('B' | 2);
}
int main() {
    char c;
    return c; 
}
int main() {
    return 'A';
}

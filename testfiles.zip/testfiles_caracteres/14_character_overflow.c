int main() {
    return 'A' + 300; 
}
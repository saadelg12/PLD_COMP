int main() {
    return ('A' & 'B') | !'C';
}
int main() {
    return 'a' > 'Z';
}

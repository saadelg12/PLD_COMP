int main() {
    return '!' == 33;
}

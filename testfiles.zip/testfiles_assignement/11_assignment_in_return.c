int main() {
    int a;
    return a = 42;
}
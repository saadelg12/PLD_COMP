int main() {
    int b;
    int c;
    int a = b = c = 3;
    return c;
}
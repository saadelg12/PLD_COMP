int main() {
    int a;
    int b;
    a = b = 3 * 2 + 1;
    return a;
}
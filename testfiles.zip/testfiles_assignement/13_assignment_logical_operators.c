int main() {
    int a;
    int b = 1;
    int c = 0;
    a = b & c | !b;
    return a;
}
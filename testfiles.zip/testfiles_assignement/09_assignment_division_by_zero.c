int main() {
    int a;
    int b = 10;
    int c = 0;
    a = b / c;
    return a;
}
int main() {
    int a;
    int b = 2147483647; // Maximum value for a 32-bit signed integer
    a = b + 1;
    return a;
}
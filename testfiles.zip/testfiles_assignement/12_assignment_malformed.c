int main() {
    int a;
    int b;
    int c;
    a = 3 = c;
    return a;
}
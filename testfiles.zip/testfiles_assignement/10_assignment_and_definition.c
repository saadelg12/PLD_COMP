int main() {
    int a=1;
    int b=2;
    int c=4;
    a = c = b = 3;
    return c;
}
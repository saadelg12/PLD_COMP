int main() {
    int a;
    int b;
    int c;
    a = b = c = 3;
    return c;
}
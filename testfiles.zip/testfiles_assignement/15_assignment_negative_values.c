int main() {
    int a;
    int b = -5;
    a = b * -2;
    return a;
}
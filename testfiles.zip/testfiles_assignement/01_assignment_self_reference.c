int main() {
    int a = 10;
    a = a + 5;
    return a;
}
#include <stdio.h>

int main() {
    int a = getchar();
    int b = getchar();
    putchar(b);
    putchar(a);
    return 0;
}

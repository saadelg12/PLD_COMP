#include <stdio.h>

int main() {

    getchar();
    
    return 0;
}
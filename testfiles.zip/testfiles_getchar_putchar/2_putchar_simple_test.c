#include <stdio.h>

int main() {
    putchar('A');
    return 0;
}

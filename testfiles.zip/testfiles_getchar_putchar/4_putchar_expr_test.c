#include <stdio.h>

int main() {
    putchar('A' + 1);
    return 0;
}
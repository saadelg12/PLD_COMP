#include <stdio.h>

int main() {
    int a = 66;
    putchar(a);
    return 0;
}

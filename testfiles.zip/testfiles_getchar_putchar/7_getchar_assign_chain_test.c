#include <stdio.h>

int main() {
    int a;
    int b;
    a = getchar();
    b = a;
    putchar(b);
    return 0;
}

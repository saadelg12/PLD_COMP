#include <stdio.h>

int main() {
    int c;
    c = getchar();
    putchar(c);
    return 0;
}

int main() {
    int x = 10;
    int y = 0;
    
    while(x > 0) {
        y =y + 2;
        x = x - 1;
    }
    
    return y;
}
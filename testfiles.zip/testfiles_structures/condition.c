int main() {
    int a = 1;
    int b = 3;
    if(a==b){
        return a;
    }else{
        return b;
    }
}

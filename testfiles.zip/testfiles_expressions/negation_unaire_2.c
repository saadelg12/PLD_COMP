int main() {
    return !((3 - 3) * 2);
}

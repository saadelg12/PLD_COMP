int main() {
    return 5/10*2;
}

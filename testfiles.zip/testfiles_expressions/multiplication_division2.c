int main() {
    return 10/5*2;
}

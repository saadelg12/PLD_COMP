int main() {
    int a = 3;
    return -a;
}

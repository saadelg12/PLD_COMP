int main() {
    int a = 5;
    int b = 10;
    return (16+((a + b)*2)-(15/5)+12)*3;
}
int main() {
    int a = 3;
    int b = 5;
    return a * b;
}

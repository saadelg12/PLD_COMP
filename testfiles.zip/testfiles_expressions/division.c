int main() {
    int a = 12;
    int b = 3;
    return a / b;
}

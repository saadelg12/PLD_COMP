int main() {
    int a = 2;
    int b = 4;
    int c = 6;
    return (a + b) * (c + 3);
}
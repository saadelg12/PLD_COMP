int main() {
    int a=3;
    int b = 4;
    {
        b = a;
    }
    return b;
}

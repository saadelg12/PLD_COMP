int main() {
    int x = 5;
    {
        int x = 10; 
        return x;
    }
}
int main() {
    int a=3;
    {
        int b = 8;
    }
    return b;
}

int main() {
    int a=3;
    int b = 4;
    int c = 5;
    {
        c = 10;
    }
    return c;
}

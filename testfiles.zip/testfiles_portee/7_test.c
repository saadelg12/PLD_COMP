int main() {
    int a=3;
    
    
    b =a;
    
    int b = a;

    return b;
}

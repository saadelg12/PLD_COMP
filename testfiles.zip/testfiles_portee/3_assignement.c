int main() {
    int a;
    a=3;
    return a;
}

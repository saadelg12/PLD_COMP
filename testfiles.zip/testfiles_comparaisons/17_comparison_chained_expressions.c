int main() {
    return (1 < 2) &  (2 < 3) & (3 == 3);
}
int main() {
    return -5 < -3;
}
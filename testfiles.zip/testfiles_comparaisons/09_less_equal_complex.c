int main() {
    return 4 <= 4;
}

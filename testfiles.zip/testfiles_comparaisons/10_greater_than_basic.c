int main() {
    return 9 > 3;
}

int main() {
    int a = 5;
    int b = 10;
    int c = 15;
    int d = 20;
    return (a + b) <= (c - d/4);
}
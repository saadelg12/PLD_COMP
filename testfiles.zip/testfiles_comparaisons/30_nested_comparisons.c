int main() {
    int a = 5;
    int b = 10;
    int c = 15;
    return (a < b) & ((b < c) | (a == c));
}
int main() {
    return 6 <= 4;
}

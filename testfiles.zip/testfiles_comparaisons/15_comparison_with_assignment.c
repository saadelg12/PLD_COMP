int main() {
    int a;
    int b;
    a = 15;
    b = 15;
    return a == b;
}
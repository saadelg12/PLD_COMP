int main() {
    int a = (6 & 3);  
    int b = (5 | 2);  
    return (a < b);
}
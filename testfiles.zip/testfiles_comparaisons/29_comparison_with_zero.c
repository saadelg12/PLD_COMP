int main() {
    return 0 == 0 ;
}
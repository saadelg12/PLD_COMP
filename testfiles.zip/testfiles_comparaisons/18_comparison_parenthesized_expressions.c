int main() {
    return ((5 + 3) * 2) > ((4 - 1) * 5);
}
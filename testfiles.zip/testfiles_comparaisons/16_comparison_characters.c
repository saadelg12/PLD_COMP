int main() {
    return 'A' < 'a';
}
int main() {
    int a = 0;
    return !a == 1;
}
int main() {
    return 7 != 7;
}

int main() {
    return 1 >= 4;
}

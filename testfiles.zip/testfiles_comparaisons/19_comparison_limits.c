int main() {
    int max = 2147483647;  
    int min = -2147483648; 
    return min < max;
}
int main() {
    return 3 < 9;
}

int main() {
    return 2 <= 4;
}

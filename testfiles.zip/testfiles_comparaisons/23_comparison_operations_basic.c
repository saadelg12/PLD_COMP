int main() {
    int a = (1 * (2 + 3) / 5);
    int b = (2 * (3 - 4) / 7);
    return (a >= b);
}

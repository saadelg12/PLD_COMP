int main() {
    int c = (-1 * (2 + 3) / 5);
    int d = (2 * (3 + 4) % (-7));

    return (c == d);
}

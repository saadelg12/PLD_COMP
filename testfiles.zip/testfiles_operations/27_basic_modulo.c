int main() {
    int a = 12;
    int b = 5;
    return a % b;
}
int main() {
    int a = 5;
    int b = 3;
    
    return -a + b;
}
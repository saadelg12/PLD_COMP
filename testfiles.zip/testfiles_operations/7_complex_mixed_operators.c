int main() {
    int a = 8;
    int b = 4;
    int c = 2;
    int d = 6;
    
    return (a / b * c) + (d - b) % c;
}
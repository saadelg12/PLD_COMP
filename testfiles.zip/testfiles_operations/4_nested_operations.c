int main() {
    int a = 5;
    int b = 3;
    int c = 7;
    int d = 2;
    
    return ((a + b) * (c - d)) + ((a - b) * (c + d));
}
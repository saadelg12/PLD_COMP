int main() {
    int a = 10;
    int b = 5;
    int c = 3;
    
    return a - b + c;
}
int main() {
    int a = 10;
    int b = 4;
    return a - b;
}
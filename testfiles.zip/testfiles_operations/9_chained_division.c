int main() {
    int a = 100;
    int b = 5;
    int c = 2;
    
    return a / b / c;
}
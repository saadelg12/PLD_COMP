int main() {
    int a = 1;
    int b = 3;
    return a + b;
}
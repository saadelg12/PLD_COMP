int main() {
    int a = 7;
    int b = 2;
    
    return a / b;
}
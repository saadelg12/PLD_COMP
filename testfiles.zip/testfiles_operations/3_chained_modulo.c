int main() {
    int a = 100;
    int b = 30;
    int c = 7;
    
    return (a % b) % c;
}
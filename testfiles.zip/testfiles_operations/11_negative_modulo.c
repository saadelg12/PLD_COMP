int main() {
    int a = -7;
    int b = 3;
    
    return a % b;
}
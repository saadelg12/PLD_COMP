int main() {
    int a = 7;
    int b = 3;
    int c = 2;
    
    return -a + b * c;
}
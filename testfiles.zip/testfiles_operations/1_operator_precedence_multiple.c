int main() {
    int a = 3;
    int b = 4;
    int c = 5;
    int d = 2;
    return a * b + c / d;  
}
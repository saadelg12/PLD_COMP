int main() {
    int a = 10;
    int b = 0;
    
    return a / b;
}
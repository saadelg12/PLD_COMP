int main() {
    int a = 20;
    int b = 6;
    int c = 2;
    
    return a % b * c;
}
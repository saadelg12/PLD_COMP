int main() {
    int a = 1000000;
    int b = 1000000;
    
    return a * b;
}
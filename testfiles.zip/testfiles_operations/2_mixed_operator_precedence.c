int main() {
    int a = 10;
    int b = 5;
    int c = 2;
    int d = 8;
    
    return a - b / c + d * c;  
}
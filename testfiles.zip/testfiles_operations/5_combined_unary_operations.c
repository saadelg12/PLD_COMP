int main() {
    int a = 5;
    int b = 0;
    
    return -(-a) + !b;
}
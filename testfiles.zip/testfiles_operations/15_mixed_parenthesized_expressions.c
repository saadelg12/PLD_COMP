int main() {
    int a = 5;
    int b = 3;
    int c = 2;
    int d = 4;
    
    return (a * (b + c)) - ((d / c) * b);
}
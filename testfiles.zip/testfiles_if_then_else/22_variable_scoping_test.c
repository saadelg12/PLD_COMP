int main() {
    int a = 5;
    int result = 0;
    
    if(a > 0) {
        int b = 10;  
        result = a + b;
    } else {
        int b = 20;  
        result = a - b;
    }
    
    
    return result;
}
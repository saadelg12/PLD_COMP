int main() {
    int a = 5;
    int b = 10;
    
    if(a < b) {
        a = a + 10;
    } else {
        a = a - 5;
    }
    
    return a;
}
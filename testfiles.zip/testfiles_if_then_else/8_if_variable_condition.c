int main() {
    int condition = 1;
    int result;
    
    if(condition) {
        result = 100;
    } else {
        result = 200;
    }
    
    return result;
}
int main() {
    int a = 5;    
    int b = 3;    
    int result;
    
    if(a & b) {  
        result = 100;
    } else {
        result = 200;
    }
    
    return result;
}
int main() {
    int a = 0;
    int result;
    
    if(!a) {
        result = 42;
    } else {
        result = 24;
    }
    
    return result;
}
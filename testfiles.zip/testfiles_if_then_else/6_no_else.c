int main()
{
    int a = 5;
    int b = 15;
    int c =5;
    int result = 0;

    if ((a+c) < b)
    {

        result = result + 5;
    }
    

    return result;
}
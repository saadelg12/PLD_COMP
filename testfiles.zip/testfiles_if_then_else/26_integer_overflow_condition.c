int main() {
    int a = 2147483647;  
    int result = 0;
    
    if(a + 1 > 0) {
        result = 1;  
    } else {
        result = 2;
    }
    
    return result;
}
int main() {
    int result;
    
    if(5 + 3 > 7) {
        result = 100;
    } else {
        result = 200;
    }
    
    return result;
}
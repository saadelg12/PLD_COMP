int main() {
    char a = 'A';
    char b = 'B';
    int result;
    
    if(a < b) {
        result = 65;  
    } else {
        result = 66;  
    }
    
    return result;
}
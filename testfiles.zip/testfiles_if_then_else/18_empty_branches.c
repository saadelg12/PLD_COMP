int main() {
    int a = 10;
    int result = 5;
    
    if(a > 5) {
    } else {
        
    }
    
    return result;
}
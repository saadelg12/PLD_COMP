int main() {
    int a = 10;
    int b = 10;
    int result;
    
    if(a <= b) {
        result = 100;
    } else {
        result = 0;
    }
    
    return result;
}
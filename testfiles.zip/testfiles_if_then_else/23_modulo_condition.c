int main() {
    int a = 10;
    int b = 3;
    int result;
    
    if(a % b == 1) {
        result = 100;
    } else {
        result = 200;
    }
    
    return result;
}
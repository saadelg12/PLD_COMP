int main() {
    int a;
    
    if(1) {
        a = 42;
    } else {
        a = 24;
    }
    
    return a;
}
int main() {
    int a = 5;
    int b = 0;
    int c = 15;
    int result;
    
    if(!b & a < c) {
        result = 42;
    } else {
        result = 24;
    }
    
    return result;
}
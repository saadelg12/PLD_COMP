int main() {
    int a = 1;
    int b= 1;
    int c;

    if(0){
        c =5;
    }else{
        c=10;
    }
    
    return c;
}

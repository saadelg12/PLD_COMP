int function(int a) {
    int b = a+6;
    return b;
}

int main() {
    int a = 10;
    int b= function(a);
    return b;
}


int function(int a) {
    int b = a+6;
    return b;
}
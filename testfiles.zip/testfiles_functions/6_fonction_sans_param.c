int function() {
    int c = 6;
    return c;
}

int main() {
    int b = function();
    return b;
}
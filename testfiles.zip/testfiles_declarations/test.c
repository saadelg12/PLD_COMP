int main() {

    return 7 + 4 * 3 + 2; 
}

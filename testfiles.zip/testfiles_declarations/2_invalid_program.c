Si ça c'est du C, moi je suis prof de manga.

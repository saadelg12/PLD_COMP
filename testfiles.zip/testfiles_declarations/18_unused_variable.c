int main() {
    int b;
    return 0;
}

int main() {
    int a = 'A' + 'B';
    return a;
}
int main() {
    int x;
    x = 10;
}

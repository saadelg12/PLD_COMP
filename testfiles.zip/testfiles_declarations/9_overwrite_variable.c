int main() {
    int a;
    a = 10;
    a = 20;
    return a;
}

int main() {
    int a = 10 > 5;
    int b = 7 < 3;
    int c = (8 >= 8) + (9 <= 10);
    return a + b + c;
}
int main() {
    int a = 17 % 5;
    int b = 20 % 6;
    return a * b;
}
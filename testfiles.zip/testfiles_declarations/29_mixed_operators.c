int main() {
    int a = 15 / 3 * (2 + 1) - 4 % 3;
    return a;
}
int main() {
    int a = 5, b = 10, c = 15;
    return a + b + c;
}
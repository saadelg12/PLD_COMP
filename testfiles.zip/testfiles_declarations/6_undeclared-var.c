int main() {
    a = 10;
    return a;
}

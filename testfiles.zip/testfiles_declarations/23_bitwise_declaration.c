int main() {
    int a = 5 & 3;
    int b = 5 | 3;
    int c = 5 ^ 3;
    return a + b + c;
}
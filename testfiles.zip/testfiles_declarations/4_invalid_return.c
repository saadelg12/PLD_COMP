// int main() {
//     return "hello";  // Erreur : return d'une chaîne au lieu d'un entier
// }

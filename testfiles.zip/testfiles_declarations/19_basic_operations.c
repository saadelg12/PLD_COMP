int main() {
    int a = 4 - 1;
    return a;
}

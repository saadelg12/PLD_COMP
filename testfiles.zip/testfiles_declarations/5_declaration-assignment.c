#include <inttypes.h>
int main() {
    int a = 42;
    return a;
}
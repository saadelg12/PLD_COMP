int main() {
    int x;
    x=8;
    return x;
}

int main() {
    int a = 1 == 1;
    int b = 5 != 3;
    int c = !0;
    return a + b + c;
}
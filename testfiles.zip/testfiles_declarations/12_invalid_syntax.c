int main() {
    int a;
    a 10;  // ❌ Erreur : Il manque un `=`
    return a;
}

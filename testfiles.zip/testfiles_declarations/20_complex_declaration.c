int main() {
    int a = 5 * (3 + 2) - 4 / 2;
    return a;
}
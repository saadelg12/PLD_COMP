 int main() {
    int b;
    int b; 
    return 0;
}

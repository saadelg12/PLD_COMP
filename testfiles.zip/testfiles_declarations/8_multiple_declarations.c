int main() {
    int x;
    int y;
    x = 5;
    y = x;
    return y;
}

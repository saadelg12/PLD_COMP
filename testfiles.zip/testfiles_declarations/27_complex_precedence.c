int main() {
    int a = 3 + 4 * 2 / (1 - 5) & 7;
    return a;
}
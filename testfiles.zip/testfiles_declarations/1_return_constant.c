int main() {
   return 42;
}
